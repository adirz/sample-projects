import oop.ex3.*;

public class SpaceShipFactory {
    public static SpaceShip[] createSpaceShips(String[] args) {
        return null;
    }
}
